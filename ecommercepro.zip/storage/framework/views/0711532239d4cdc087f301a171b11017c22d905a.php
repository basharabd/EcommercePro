<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="<?php echo e(asset('front/images/favicon.png')); ?>" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/bootstrap.css')); ?>" />
      <!-- font awesome style -->
      <link href="<?php echo e(asset('front/css/font-awesome.min.css')); ?>" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" />
      <!-- responsive style -->
      <link href="<?php echo e(asset('front/css/responsive.css')); ?>" rel="stylesheet" />
      <style type="text/css">
      .cart{
        margin: auto;
        width: 70%;
        text-align: center;
        padding: 10px;
      }


      </style>

    </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
     <?php echo $__env->make('Front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- end header section -->

         <?php if(session()->has('success')): ?>
         <div class=" alert alert-danger">
             <?php echo e(session()->get('success')); ?>

         </div>
         <?php endif; ?>

     <div class="cart">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>User Name</th>
                <th>User Email</th>
                <th>User Phone</th>
                <th>User Address</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Quantitiy</th>
                <th>Product Image</th>
                <th>Remove</th>


            </tr>
            </thead>
            <tbody>

                <?php $totalprice = 0 ;?>

              <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($cart->name); ?></td>
                <td><?php echo e($cart->email); ?></td>
                <td><?php echo e($cart->phone); ?></td>
                <td><?php echo e($cart->address); ?></td>
                <td><?php echo e($cart->product_name); ?></td>
                <td>$<?php echo e($cart->price); ?></td>
                <td><?php echo e($cart->quantity); ?></td>
                <td> <img
                    src="<?php echo e(asset('/uploads/' . $cart->image)); ?>" height="400px" width="400px">
                </td>

                <td><a href="<?php echo e(url("remove_cart" , $cart->id)); ?>" onclick ="return confirm('Are You Sure to remove this product?!')" class="btn btn-sm btn-danger">Remove</a></td>

              </tr>


              <?php $totalprice =   $totalprice + $cart->price?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

          </table>
          <div>
            <h1 style="font-size: 20px; padding:40px; color:red;">Total Price :$ <?php echo e($totalprice); ?></h1>
        </div>

        <div class="">
            <h1 style="font-size: 25px; padding-bottom:15px;p">Proceed To Order</h1>

            <a href="<?php echo e(url('cash_order')); ?>" class="btn btn-danger">Cash On Delivery</a>
            <a href="<?php echo e(url('stripe' , $totalprice)); ?>" class="btn btn-danger">Pay Using Card</a>


        </div>
     </div>








      <!-- footer start -->
     <?php echo $__env->make('Front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- footer end -->
     <?php echo $__env->make('Front.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- jQery -->
      <script src="<?php echo e(asset('front/js/jquery-3.4.1.min.js')); ?>"></script>
      <!-- popper js -->
      <script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
      <!-- bootstrap js -->
      <script src="<?php echo e(asset('front/js/bootstrap.js')); ?>"></script>
      <!-- custom js -->
      <script src="<?php echo e(asset('front/js/custom.js"')); ?>></script>
   </body>
</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Front/cart.blade.php ENDPATH**/ ?>