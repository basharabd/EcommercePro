<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="<?php echo e(asset('front/images/favicon.png')); ?>" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/bootstrap.css')); ?>" />
      <!-- font awesome style -->
      <link href="<?php echo e(asset('front/css/font-awesome.min.css')); ?>" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" />
      <!-- responsive style -->
      <link href="<?php echo e(asset('front/css/responsive.css')); ?>" rel="stylesheet" />
      <style type="text/css">
      .cart{
        margin: auto;
        width:77%;
        text-align: center;
        padding: 10px;
      }


      </style>

    </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
     <?php echo $__env->make('Front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- end header section -->

         <?php if(session()->has('success')): ?>
         <div class=" alert alert-danger">
             <?php echo e(session()->get('success')); ?>

         </div>
         <?php endif; ?>

     <div class="cart">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>User Name</th>
                <th> Email</th>
                <th> Phone</th>
                <th>Address</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>quantity</th>
                <th>Image</th>
                <th>Payment  Status</th>
                <th>Delivery Status</th>

                <th>Cancel Order</th>





            </tr>
            </thead>
            <tbody>




              <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($order->name); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->phone); ?></td>
                <td><?php echo e($order->address); ?></td>
                <td><?php echo e($order->product_name); ?></td>
                <td><?php echo e($order->price); ?></td>
                <td><?php echo e($order->quantity); ?></td>

                <td>
                    <img src="<?php echo e(asset('/uploads/' . $order->image)); ?>">
                 </td>

                <td><?php echo e($order->payment_status); ?></td>
                <td><?php echo e($order->delivery_status); ?></td>

                <td>
                    <?php if($order->delivery_status=='processing'): ?>

                    <a href="<?php echo e(url('cancel_order',$order->id)); ?>"
                         onclick="return Confirm('Are You Sure To Cancel This Order!!')"
                         class="btn btn-danger">Cancel Order</a>

                    <?php else: ?>

                    <p style="color: blue;">Not Allowed!</p>


                    <?php endif; ?>


                </td>

              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                  <td colspan="11">

                      <div class="alert alert-info text-center" style="font-size: 1.5rem;" role="alert">
                          No Orders Defined!
                      </div>

                  </td>
              </tr>



          <?php endif; ?>







            </tbody>



          </table>



     </div>








      <!-- footer start -->
     <?php echo $__env->make('Front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- footer end -->
     <?php echo $__env->make('Front.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- jQery -->
      <script src="<?php echo e(asset('front/js/jquery-3.4.1.min.js')); ?>"></script>
      <!-- popper js -->
      <script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
      <!-- bootstrap js -->
      <script src="<?php echo e(asset('front/js/bootstrap.js')); ?>"></script>
      <!-- custom js -->
      <script src="<?php echo e(asset('front/js/custom.js"')); ?>></script>
   </body>
</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Front/order.blade.php ENDPATH**/ ?>