
<!DOCTYPE html>
<html lang="en">
  <head>
 <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
       <?php echo $__env->make('Admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->

        <div class="main-panel">
            <div class="content-wrapper bg-white">

    <div class="container-fluid">
        <div class="card">
            <div class="card-footer">
                <i class="fas fa-pencil-alt"></i>

                Add Category

            </div>


            <div class=" container-fluid mb-3 ">
                <a href="<?php echo e(route('category.index')); ?>" title="Back" class="btn btn-danger mt-2 float-right"><i
                        class="fas fa-reply"></i></a>
            </div>

            <hr />
            <div class="card-body">

                <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>



                    <div class="row mb-3 ">
                        <label class="col-sm-2 col-form-label">Category Name</label>
                        <div class="col-sm-10">
                            <input type="text" style="color: black;" name="name" value="" placeholder="Category Name"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class=" invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <hr />


                    <div class="row mb-3 ">
                        <label class="col-sm-2 col-form-label">Category Description</label>
                        <div class="col-sm-10">
                            <input type="text" style="color: black;" name="description" value="" placeholder="Category Description"
                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class=" invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <hr />



                    <div class="row mb-3 ">
                        <label class="col-sm-2 col-form-label" for="status"><?php echo e(__('Status')); ?></label>

                        <div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" value="Active"
              >

                                <label class="form-check-label">
                                    <?php echo e(__('Active')); ?>

                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" value="NotActive"
                                    >
                                <label class="form-check-label">
                                    <?php echo e(__('InActive')); ?>

                                </label>
                            </div>

                        </div>

                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class=" invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                    <div class="row mt-5  float-right">

                        <button type="submit" class=" btn btn-success"><i class="fa-solid fa-floppy-disk"></i></button>

                    </div>




                </form>

            </div>


        </div>
    </div>
            </div>
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
   <?php echo $__env->make('Admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Admin/categories/create.blade.php ENDPATH**/ ?>