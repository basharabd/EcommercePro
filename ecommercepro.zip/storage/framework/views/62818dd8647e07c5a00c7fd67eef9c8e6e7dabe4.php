<section class="product_section layout_padding">
    <div class="container">
       <div class="heading_container heading_center">
          <h2>
             Our <span>products</span>
          </h2>
       </div>

       <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



       <?php if(session()->has('success')): ?>
       <div class=" alert alert-danger">
           <?php echo e(session()->get('success')); ?>

       </div>
   <?php endif; ?>



       <div>
          <form action="<?php echo e(url('search_product')); ?>" method="get">
            <?php echo csrf_field(); ?>
             <input type="text" name="search" placeholder="Search For Products">
<br><br>
             <input type="submit" value="search">
          </form>
       </div>

       <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-sm-6 col-md-4 col-lg-4">
           <div class="box">
              <div class="option_container">
                 <div class="options">
                    <a href="<?php echo e(route('products.show',$product->id)); ?>" class="option1">
                    Product Detail
                    </a>

                    <form action="<?php echo e(url('add_cart',$product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class=" row">

                            <div class=" col-md-4">
                                <input type="number" name="quantity" value="1" min="1" style="width: 100px;">

                            </div>

                            <div class=" col-md-4">
                                <input type="submit" value="Add To Cart">

                            </div>
                        </div>


                    </form>
                 </div>
              </div>
              <div class="img-box">
                  <img
                  src="<?php echo e(asset('/uploads/' . $product->image)); ?>"
               >                </div>
              <div class="detail-box">
                 <h5>
                    <?php echo e($product->name); ?>

                 </h5>

                 <?php if($product->discount_price!=null): ?>
                 <h5 class=" text-center" style="color: red">
                    Discount
                    <br>

                  $  <?php echo e($product->discount_price); ?>


                 </h5>

                 <h6 style="text-decoration: line-through; color:blue">
                    Price
                    <br>
                   $ <?php echo e($product->price); ?>

                 </h6>

                 <?php else: ?>

                 <h6 style="color: blue;">
                    Price
                    <br>
                    <?php echo e($product->price); ?>

                 </h6>
                 <?php endif; ?>

                 








              </div>
           </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="9">

                <div class="alert alert-info text-center"
                    style="font-size: 1.5rem;" role="alert">
                    No Products Defined!
                </div>

            </td>
        </tr>

        <?php endif; ?>
       </div>




       <div class="btn-box">
         <a href="<?php echo e(url('view_all_product')); ?>">
         View All products
         </a>
      </div>


    </div>



 </section>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Front/product.blade.php ENDPATH**/ ?>