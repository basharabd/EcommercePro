<div class="cpy_">
    <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

       Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

    </p>
 </div>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Front/copyright.blade.php ENDPATH**/ ?>