<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('Admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">

                    <?php if(session()->has('success')): ?>
                        <div class=" alert alert-danger">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container-fluid">
                        <div class="card">
                            <div class="card-footer">
                                <i class="fas fa-list"></i>
                                Product List

                            </div>
                            <hr />




                            <hr />
                            <div class=" container-fluid mb-2">
                                <a href="<?php echo e(route('products.create')); ?>" title="Add New"
                                    class="btn btn-primary float-right mx-4"><i class="fas fa-plus"></i></a>

                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Product Description</th>
                                                <th> Category</th>

                                                <th>Product Price</th>
                                                <th>Product Image</th>

                                                <th>Status</th>
                                                <th>Discount Price</th>
                                                <th>Edit</th>
                                                <th>Delete</th>

                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>


                                                    <td><?php echo e($product->name); ?></td>
                                                    <td><?php echo e($product->description); ?></td>
                                                    <td><?php echo e($product->category); ?></td>
                                                    <td><?php echo e($product->price); ?></td>
                                                    <td><img
                                                            src="<?php echo e(asset('/uploads/' . $product->image)); ?>"
                                                         ></td>
                                                    <td><?php echo e($product->status); ?></td>
                                                    <td><?php echo e($product->discount_price); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                            class=" btn btn-sm btn-primary" title="Eidt"
                                                            style="margin-bottom: .5rem"><i
                                                                class="fas fa-pencil-alt"></i></a>

                                                    </td>

                                                    <td>
                                                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button type="submit"
                                                                onclick="return confirm('Are You Sure To Deleted This')"
                                                                class=" btn btn-sm btn-danger" title="Delete"><i
                                                                    class="fas fa-trash-alt"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="9">

                                                        <div class="alert alert-info text-center"
                                                            style="font-size: 1.5rem;" role="alert">
                                                            No Products Defined!
                                                        </div>

                                                    </td>
                                                </tr>
                                            <?php endif; ?>


                                        </tbody>

                                    </table>

                                    


                                </div>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <?php echo $__env->make('Admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Admin/products/index.blade.php ENDPATH**/ ?>