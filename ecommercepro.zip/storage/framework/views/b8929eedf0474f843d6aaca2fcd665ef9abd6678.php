
<!DOCTYPE html>
<html lang="en">
  <head>
 <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
       <?php echo $__env->make('Admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">



            <div style="padding-left: 400px;padding-bottom:30px;">

                <form action="<?php echo e(url('search')); ?>" method="get">
                    <?php echo csrf_field(); ?>

                    <input type="text"  style="color: black;" name="search" placeholder="Search For Somethings">
                    <input type="submit" value="search" class="btn btn-outline-behance">

                </form>
            </div>
                <?php if(session()->has('success')): ?>
                <div class=" alert alert-danger">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-footer">
                        <i class="fas fa-list"></i>
                      All Orders

                    </div>
                    <hr />



                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">User Name</th>
                                    <th class=" text-center"> Email</th>
                                    <th class=" text-center"> Phone</th>

                                    <th class=" text-center">Address</th>
                                    <th class=" text-center">Product Name</th>

                                    <th class=" text-center">Product Price</th>
                                    <th class=" text-center">quantity</th>
                                    <th class="text-center">Image</th>
                                    <th class="text-center">Payment  Status</th>
                                    <th class="text-center">Delivery Status</th>

                                    <th class="text-center">Delivered</th>

                                    <th class="text-center">Download PDF File</th>






                                </tr>
                            </thead>

                            <tbody>

                               <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>


                                        <td class=" text-center"><?php echo e($order->name); ?></td>
                                        <td class=" text-center"><?php echo e($order->email); ?></td>
                                        <td class=" text-center"><?php echo e($order->phone); ?></td>
                                        <td class=" text-center"><?php echo e($order->address); ?></td>
                                        <td class=" text-center"><?php echo e($order->product_name); ?></td>
                                        <td class=" text-center"><?php echo e($order->price); ?></td>
                                        <td class=" text-center"><?php echo e($order->quantity); ?></td>

                                        <td class=" text-center">
                                            <img src="<?php echo e(asset('/uploads/' . $order->image)); ?>">
                                         </td>

                                        <td class=" text-center"><?php echo e($order->payment_status); ?></td>
                                        <td class=" text-center"><?php echo e($order->delivery_status); ?></td>

                                        <td class=" text-center">
                                            <?php if( $order->delivery_status =='processing'): ?>
                                            <a href="<?php echo e(url('delivered' , $order->id)); ?>" onclick="return confirm('Are You Sure This Product is delivered!!! ')" class="btn btn-primary">Delivered</a>

                                            <?php else: ?>
                                            <p style="color: green;">Delivered</p>


                                            <?php endif; ?>
                                            </td>

                                            <td class=" text-center"><a href="<?php echo e(url('download_pdf',$order->id)); ?>" class="btn btn-secondary">PDF File</a></td>




                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9">

                                            <div class="alert alert-info text-center"
                                                style="font-size: 1.5rem;" role="alert">
                                                No Orders Defined!
                                            </div>

                                        </td>
                                    </tr>


                                <?php endif; ?>


                            </tbody>

                        </table>



                    </div>


                </div>

            </div>
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
   <?php echo $__env->make('Admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Admin/orders/index.blade.php ENDPATH**/ ?>