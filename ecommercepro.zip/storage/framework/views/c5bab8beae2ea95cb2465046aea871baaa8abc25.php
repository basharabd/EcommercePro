<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <h1 style="text-align: center; color:red;">
      Order Detail
    </h1>

<hr/>

       Coustmer Name :         <h3><?php echo e($orders->name); ?></h3>
       <hr/>

       Coustmer Email :   <h3><?php echo e($orders->email); ?></h3>
       <hr/>
       Coustmer Phone :   <h3><?php echo e($orders->phone); ?></h3>
       <hr/>
       Coustmer Address :    <h3><?php echo e($orders->address); ?></h3>
       <hr/>
          Product Name  :    <h3><?php echo e($orders->product_name); ?></h3>
          <hr/>
          Product Price  :   <h3><?php echo e($orders->price); ?></h3>
          <hr/>
          Product Quantity :   <h3><?php echo e($orders->quantity); ?></h3>
          <hr/>
             Product ID  : <h3><?php echo e($orders->product_id); ?></h3>
             <hr/>
            User ID :    <h3><?php echo e($orders->user_id); ?></h3>
            <hr/>
             Payment Status  :  <h3><?php echo e($orders->payment_status); ?></h3>
             <hr/>
               Delivery Status : <h3><?php echo e($orders->delivery_status); ?></h3>
           





</body>
</html>
<?php /**PATH F:\laravel\EcommercePro\resources\views/Admin/pdf/download.blade.php ENDPATH**/ ?>